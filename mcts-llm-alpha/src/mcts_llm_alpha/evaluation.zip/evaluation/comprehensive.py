#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
综合评估模块，集成所有评估方法。

该模块将模拟、Qlib评估、相对排名和LLM过拟合评估
结合成一个统一的评估框架。
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
import logging

from .qlib_evaluator import evaluate_formula_qlib
from .relative_ranking import RelativeRankingEvaluator
from ..llm.overfitting_evaluator import evaluate_overfitting_risk_sync
from ..config import Config

logger = logging.getLogger(__name__)


class ComprehensiveEvaluator:
    """
    基于配置结合所有评估方法的统一评估器。
    """
    
    def __init__(self, config: Config, llm_client=None):
        """
        初始化综合评估器。
        
        参数：
            config: 配置对象
            llm_client: 用于过拟合评估的LLM客户端
        """
        self.config = config
        self.llm_client = llm_client
        self.ranking_evaluator = RelativeRankingEvaluator(
            effectiveness_threshold=config.evaluation.effectiveness_threshold
        )
        
    def evaluate_formula(
        self, 
        formula: str,
        repo_factors: List[pd.DataFrame],
        node: Optional[Any] = None
    ) -> Tuple[Optional[Dict[str, float]], Optional[pd.DataFrame]]:
        """
        综合公式评估。
        
        参数：
            formula: 要评估的Alpha公式
            repo_factors: 现有因子的仓库
            node: 用于上下文的MCTS节点（可选）
            
        返回：
            元组 (scores, factor_dataframe)
        """
        try:
            # 步骤1: 使用Qlib获取原始指标（移除模拟评估）
            raw_scores, factor_df = self._evaluate_with_qlib(formula, repo_factors)
                
            if raw_scores is None:
                return None, None
                
            # 步骤2: 使用相对排名评估（按照论文要求，移除绝对值归一化）
            scores = self.ranking_evaluator.evaluate_formula_with_relative_ranking(
                raw_scores, repo_factors
            )
                
            # 步骤3: 使用LLM评估过拟合风险
            if self.llm_client and node:
                overfitting_score, reason = evaluate_overfitting_risk_sync(
                    self.llm_client,
                    formula,
                    node.refinement_history if hasattr(node, 'refinement_history') else []
                )
                scores['Overfitting'] = overfitting_score
                logger.info(f"过拟合评估: {overfitting_score} - {reason}")
            else:
                # 默认过拟合分数（0-10范围的中间值）
                scores['Overfitting'] = 5.0
                
            # 步骤4: 始终将原始分数添加到相对排名评估器的仓库中
            # 这样后续的公式才能正确计算相对排名
            self.ranking_evaluator.add_to_repository(raw_scores)
                
            return scores, factor_df
            
        except Exception as e:
            logger.error(f"评估公式 {formula} 时出错: {e}")
            return None, None
            
    def _evaluate_with_qlib(
        self, 
        formula: str,
        repo_factors: List[pd.DataFrame]
    ) -> Tuple[Optional[Dict[str, float]], Optional[pd.DataFrame]]:
        """
        使用Qlib真实数据进行评估。
        """
        return evaluate_formula_qlib(
            formula,
            repo_factors,
            start_date=self.config.data.start_date,
            end_date=self.config.data.end_date,
            universe=self._get_universe(),
            split_date=self.config.evaluation.split_date,
            ic_method=self.config.evaluation.ic_method
        )
        
        
        
    def _is_valid_alpha(self, scores: Dict[str, float]) -> bool:
        """
        检查alpha是否满足有效性标准。
        """
        return (scores.get('Effectiveness', 0) >= self.config.evaluation.effectiveness_threshold and
                scores.get('Diversity', 0) >= self.config.evaluation.diversity_threshold and
                np.mean(list(scores.values())) >= self.config.evaluation.overall_threshold)
                
    def _get_universe(self) -> List[str]:
        """
        根据配置获取股票池。
        """
        # 这通常会加载实际的股票池
        # 现在，返回测试股票
        return self.config.data.test_instruments


def create_evaluator(config: Config, llm_client=None):
    """
    根据配置创建评估器的工厂函数。
    
    参数：
        config: 配置对象
        llm_client: LLM客户端实例
        
    返回：
        配置好的评估器实例
    """
    evaluator = ComprehensiveEvaluator(config, llm_client)
    return evaluator